<template>
  <div>
    <q-btn
      color="primary"
      icon="payment"
      @click="handleTransaction"
      flat
      dense
    />
  </div>
</template>

<script>
export default {
  props: {
    shopper_id: { type: String, required: true }
  },
  data() {
    return {
      transactions: [],
      shopperDetails: null
    };
  },
  methods: {
    handleTransaction: async function() {
      try {
        // const response = await this.$dbCon
        //   .service("shoppers")
        //   .get(this.shopper_id);
        // alert(response);
      } catch (e) {}
    }
  },
  mounted() {
    if (this.shopper_id) {
      this.handleTransaction();
    }
  }
};
</script>
