self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "67b5f8fcdcf62b1a70d0",
    "url": "css/20f71968.daed63e3.css"
  },
  {
    "revision": "8d6dee88cc906619b3e9",
    "url": "css/2480b02a.86b462a7.css"
  },
  {
    "revision": "6d338875d005a615d542",
    "url": "css/app.3366b199.css"
  },
  {
    "revision": "5cb7edfceb233100075dc9a1e12e8da3",
    "url": "fonts/KFOkCnqEu92Fr1MmgVxIIzQ.5cb7edfc.woff"
  },
  {
    "revision": "87284894879f5b1c229cb49c8ff6decc",
    "url": "fonts/KFOlCnqEu92Fr1MmEU9fBBc-.87284894.woff"
  },
  {
    "revision": "b00849e00f4c2331cddd8ffb44a6720b",
    "url": "fonts/KFOlCnqEu92Fr1MmSU5fBBc-.b00849e0.woff"
  },
  {
    "revision": "adcde98f1d584de52060ad7b16373da3",
    "url": "fonts/KFOlCnqEu92Fr1MmWUlfBBc-.adcde98f.woff"
  },
  {
    "revision": "bb1e4dc6333675d11ada2e857e7f95d7",
    "url": "fonts/KFOlCnqEu92Fr1MmYUtfBBc-.bb1e4dc6.woff"
  },
  {
    "revision": "60fa3c0614b8fb2f394fa29944c21540",
    "url": "fonts/KFOmCnqEu92Fr1Mu4mxM.60fa3c06.woff"
  },
  {
    "revision": "29b882f018fa6fe75fd338aaae6235b8",
    "url": "fonts/flUhRq6tzZclQEJ-Vdg-IuiaDsNa.29b882f0.woff"
  },
  {
    "revision": "0509ab09c1b0d2200a4135803c91d6ce",
    "url": "fonts/flUhRq6tzZclQEJ-Vdg-IuiaDsNcIhQ8tQ.0509ab09.woff2"
  },
  {
    "revision": "0592edc9effad975046ac0cc2c86c48b",
    "url": "index.html"
  },
  {
    "revision": "67b5f8fcdcf62b1a70d0",
    "url": "js/20f71968.dc561204.js"
  },
  {
    "revision": "8d6dee88cc906619b3e9",
    "url": "js/2480b02a.55d15b61.js"
  },
  {
    "revision": "f34ce1a10d2832cfc7dc",
    "url": "js/2d0ab84c.fe597e46.js"
  },
  {
    "revision": "c3fe184dc959b2e1e9d2",
    "url": "js/2d0abe68.738504d2.js"
  },
  {
    "revision": "98a479a79d22cc74d494",
    "url": "js/2d0aeb27.9e65832f.js"
  },
  {
    "revision": "768f36a1cd9c1fabe5ff",
    "url": "js/2d0b28c0.2a037ceb.js"
  },
  {
    "revision": "9fd6d69f01ee48cd3647",
    "url": "js/2d0b305a.668ff207.js"
  },
  {
    "revision": "e98cf92ecc8399bf8f1e",
    "url": "js/2d0b93c9.1ac40216.js"
  },
  {
    "revision": "b6da68814618b962e6ec",
    "url": "js/2d0ba736.c0af4113.js"
  },
  {
    "revision": "e23887df0ea799dca414",
    "url": "js/2d0c19e7.f92ff661.js"
  },
  {
    "revision": "f1f28472765caa28e03b",
    "url": "js/2d0c2689.858d0363.js"
  },
  {
    "revision": "a33abd0d3f902715a05c",
    "url": "js/2d0c78e1.c2e97f49.js"
  },
  {
    "revision": "8e6f2e8d7511c397f327",
    "url": "js/2d0c9347.91a23279.js"
  },
  {
    "revision": "ba30dbdb285c52623d80",
    "url": "js/2d0ceb17.e44925a3.js"
  },
  {
    "revision": "87a0b5bc7f83e50fe372",
    "url": "js/2d0d3a86.03eabf52.js"
  },
  {
    "revision": "3017f51665dcbc3a18f1",
    "url": "js/2d0da6c2.52fbfe27.js"
  },
  {
    "revision": "012a166e46cc1ff72401",
    "url": "js/2d0dd9df.bca059b2.js"
  },
  {
    "revision": "f2bc34c508e233b2b282",
    "url": "js/2d0e13c7.1019cc76.js"
  },
  {
    "revision": "e768bfd14ec20af4f33d",
    "url": "js/2d0e2191.fdb93f58.js"
  },
  {
    "revision": "dce60ca8889e2f00ad0e",
    "url": "js/2d0e4bf5.84d9d35c.js"
  },
  {
    "revision": "f9d97c3bed451f550455",
    "url": "js/2d0e55b2.07abbac9.js"
  },
  {
    "revision": "383e9d6431f2b3dc8ec3",
    "url": "js/2d0e59f2.2a7c6fad.js"
  },
  {
    "revision": "9677a5896dbdb723eec2",
    "url": "js/2d0e5d5e.78f672c2.js"
  },
  {
    "revision": "a0c30aa0f126b009a65f",
    "url": "js/2d0e8f66.6d1e86e2.js"
  },
  {
    "revision": "f594361aeeacf6b353fe",
    "url": "js/2d0e95d4.f9159819.js"
  },
  {
    "revision": "29ab04860c24c6b4bed6",
    "url": "js/2d207b39.9b037990.js"
  },
  {
    "revision": "0c17f4d2e2ef2add8e68",
    "url": "js/2d20ed77.5853f4a4.js"
  },
  {
    "revision": "a2cf9079c17ddbbc2d8d",
    "url": "js/2d2176dc.a993cdfd.js"
  },
  {
    "revision": "5a9eebf2ec0ac829800d",
    "url": "js/2d21a74c.1eb6a45a.js"
  },
  {
    "revision": "26e99fa3a06cac996203",
    "url": "js/2d225be5.8a9e9f87.js"
  },
  {
    "revision": "dde71a2a5079e0fdd778",
    "url": "js/2d2268db.d373fe10.js"
  },
  {
    "revision": "df53ec84432954d62e41",
    "url": "js/2d229490.b609ed5a.js"
  },
  {
    "revision": "c18cb63e22b21302d7ba",
    "url": "js/2d22d024.db7a7f2c.js"
  },
  {
    "revision": "1f296d6e8bf85869e31e",
    "url": "js/2d238a55.66f5f470.js"
  },
  {
    "revision": "9310052a48d44bcc5542",
    "url": "js/4b47640d.ac0bfcc7.js"
  },
  {
    "revision": "e5580db6fe8e874f555f",
    "url": "js/574b6e74.60f6ed62.js"
  },
  {
    "revision": "6d338875d005a615d542",
    "url": "js/app.8d123694.js"
  },
  {
    "revision": "650210240905898c9da8",
    "url": "js/b75834fa.afd228e0.js"
  },
  {
    "revision": "120cac1506e34a583093",
    "url": "js/b761ee6a.30c76920.js"
  },
  {
    "revision": "1376736bd7529278341f",
    "url": "js/c6c31fd2.c722951b.js"
  },
  {
    "revision": "fd12458853d8c19ff932",
    "url": "js/vendor.be9f7a53.js"
  },
  {
    "revision": "c519dc4b52c1671fd0deee3b4003c06f",
    "url": "manifest.json"
  },
  {
    "revision": "ae081952a5a908b38d91f49fe019d261",
    "url": "statics\\New folder\\enturaz-logo.png"
  },
  {
    "revision": "d490ba79d752fb64835d41d1b28fc14f",
    "url": "statics\\New folder\\icons\\apple-icon-152x152.png"
  },
  {
    "revision": "2838f560ed850f9944ac84527859a2a1",
    "url": "statics\\New folder\\icons\\favicon-16x16.png"
  },
  {
    "revision": "4ec5a14755e6134323a874894f354423",
    "url": "statics\\New folder\\icons\\favicon-32x32.png"
  },
  {
    "revision": "54e941b79bd3bb857b0342bc77e9fd3b",
    "url": "statics\\New folder\\icons\\icon-128x128.png"
  },
  {
    "revision": "b70371113d29e3434f4dbe0ce44710b8",
    "url": "statics\\New folder\\icons\\icon-192x192.png"
  },
  {
    "revision": "f52cfa9efe808f34914aa8c35d70e2a4",
    "url": "statics\\New folder\\icons\\icon-256x256.png"
  },
  {
    "revision": "c4f5c04bf83ee5b4580cb2116da5d637",
    "url": "statics\\New folder\\icons\\icon-384x384.png"
  },
  {
    "revision": "9bc8f6264ff9350bc42add470d181f9f",
    "url": "statics\\New folder\\icons\\icon-512x512.png"
  },
  {
    "revision": "e2df61be23c7680cd6d44fe59e099d38",
    "url": "statics\\New folder\\icons\\ms-icon-144x144.png"
  },
  {
    "revision": "4fa4f86f47a9ed3055b00c44fc9a0089",
    "url": "statics\\New folder\\landingPageBG.jpg"
  },
  {
    "revision": "3020c8ac2c2872dec7741e5948520093",
    "url": "statics\\New folder\\quasar-logo.png"
  }
]);